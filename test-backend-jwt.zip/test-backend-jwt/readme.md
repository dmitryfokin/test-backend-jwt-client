### `API` for test task
- [task description](./task.md)
- [vacancy](./vacancy.md)

Before start you have to launch `mongod` command in terminal
> there are a lot of tutorial how to install `mongo` 

This is my own code. You can use it as you wish. But libs, images and so on - in accordance with their license